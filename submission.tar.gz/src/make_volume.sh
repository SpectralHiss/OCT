../lib/Fiji.app/ImageJ-linux64 -macro show-render.ijm $HOME/QMUL/project/OCTune/src/../out/tooth/tuned-B-Scan/BScan/0.png
