install requirements at top level (ideally with virtualenv) with 
pip install -r requirements.txt

run pytest in test directory.
individual tests can be run with pytest -k "test.py"